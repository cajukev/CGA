<script></script>
<div class='footer'>
  <a href="/backstore/products/"> This is an incredibly underdesigned footer which links to the backstore</a>
</div>
<style>

</style>
<h1>User Sign Up</h1>
<div class="form-wrapper">
	<form action="">
		<label for="fname">First Name:</label>
		<input type="text" name="fname" id="fname" />
		<label for="email">Email*:</label>
		<input type="text" name="email" id="email" required />
		<label for="password">Password*:</label>
		<input type="password" name="password" id="password" required />
		<label for="password2">Confirm Password*:</label>
		<input type="password" name="password2" id="password2 required" />
		<button >Submit</button>
	</form>
</div>

<style>

</style>

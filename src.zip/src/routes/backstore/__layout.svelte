<h1>Super Secret Backstore</h1>
<div class="backstore-nav-wrapper">
  <div class="nav">
    <a href="/backstore/products/">Product List</a>
    <a href="/backstore/users/">User List</a>
    <a class="orders" href="/backstore/orders/">Order List</a>
  </div>
</div>

<div class="grey-bg"><slot /></div>

<style>

</style>

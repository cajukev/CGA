<h1>User Login</h1>
<div class="form-wrapper">
	<form action="">
		<label for="email">Email*:</label>
		<input type="text" name="email" id="email" required />
		<label for="password">Password*:</label>
		<input type="password" name="password" id="password" required />
		<div class="buttons">
			<button>Submit</button>
			<button>Forget Password</button>
		</div>
	</form>
</div>
